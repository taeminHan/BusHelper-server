import socket
import threading
from queue import Queue
import pymongo


class App:
    def __init__(self, conn, recv):
        self.conn = conn
        self.recv = recv

    def Login(self):
        client = pymongo.MongoClient(
            "mongodb+srv://Main:1q2w3e4r@cluster0.dbjal.gcp.mongodb.net/<dbname>?retryWrites=true&w=majority")
        db = client.get_database('Register')
        col = db.get_collection('Login')
        print('Thread Send Start')
        while True:
            try:
                recv = self.get()
                raddr = str(recv[1])
                if recv == 'Group Changed':
                    print('Group Changed')
                    break
                info = recv[0].split(':')
                if info[0] == 'login':
                    doc = col.find({'ID': info[1], 'PassWord': info[2]}) #MongoDB 로그인 정보 조회
                    if list(doc):
                        msg = 'Login OK'
                        self.conn.sendto(msg.encode(), (raddr[-19:-10], int(raddr[-7:-2])))
                    else:
                        msg = 'Login Fail'
                        self.conn.sendto(msg.encode(), (raddr[-19:-10], int(raddr[-7:-2])))
                elif info[0] == 'Register':
                    pass
            except:
                pass